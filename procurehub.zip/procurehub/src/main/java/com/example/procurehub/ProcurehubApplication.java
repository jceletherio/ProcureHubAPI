package com.example.procurehub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProcurehubApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProcurehubApplication.class, args);
	}

}
