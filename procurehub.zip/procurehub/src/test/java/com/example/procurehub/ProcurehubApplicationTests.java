package com.example.procurehub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProcurehubApplicationTests {

	@Test
	void contextLoads() {
	}

}
